<p align="center">
    <img src="https://telegra.ph/file/b88ff90238fc02a160f3e.jpg" width="50%" height="50%" alt="Relldev"/>
    <br>
    <a href="https://github.com/Zivfurr"><img title="Created by" src="https://img.shields.io/badge/Creator-Ziv San-green?style=for-the-badge&logo=github"></a>
</p>

# RECODE BY ZIV SAN

Simple WhatsApp Bot

<p align="center">
  <a href="https://github.com/zivfurr"><img src="http://readme-typing-svg.herokuapp.com?color=7FFF00&center=true&vCenter=true&multiline=false&lines=Simple+Whatsapp+Bot;Base+ori+by+Nurutomo;Give+star+and+forks+this+repo; Script+By+Ziv San" alt="UwU">
</p>

### Preview bot
------------------
- [x] Welcome <details><summary>Screenshot</summary><img src="https://telegra.ph/file/71cd738e5c43219247640.jpg"></details>
- [x] Menu <details><summary>Screenshot</summary><img src="https://telegra.ph/file/dbbe0d04c6e1b98c54014.jpg"></details>
------------------

![Ra Github languages](https://github-readme-stats.vercel.app/api/top-langs/?username=zivfurr&theme=tokyonight)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Rlxfly/bot-tzy)
 
   

---------
  
  
  # Thanks if you use this source code >//<
